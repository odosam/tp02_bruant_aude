import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-compte',
  templateUrl: './compte.component.html',
  styleUrls: ['./compte.component.css']
})

export class CompteComponent {
  clientForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.clientForm = this.fb.group({
      prenom: ['', Validators.required],
      telephone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      adresse: ['', Validators.required],
      codePostal: ['', [Validators.required, Validators.pattern(/^[0-9]{5}$/)]],
      ville: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      login: ['', Validators.required],
      pwd: ['', [Validators.required]],
      pays: ['', Validators.required],
      civilite: ['', Validators.required]
    });

  }
  onSubmit(): void {
    if (this.clientForm.valid) {
      console.log(this.clientForm.value);  
    } else {
      console.log("Le formulaire est invalide !");
    }
  }
}

